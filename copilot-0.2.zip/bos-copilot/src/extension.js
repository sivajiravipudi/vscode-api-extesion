// The module 'vscode' contains the VS Code extensibility API
// Import the module and reference it with the alias vscode in your code below
const SidebarProvider = require('./SidebarProvider').SidebarProvider;
const vscode = require('vscode');
const https = require('https');
const axios = require('axios');
//require('dotenv').config();
console.log(process.env);

// This method is called when your extension is activated
// Your extension is activated the very first time the command is executed

async function callOpenAIAPI() {
	const seletedText = vscode.window.activeTextEditor.selection;
	let text = vscode.window.activeTextEditor.document.getText(seletedText);
	if(text !=null)
	{
		text = vscode.window.activeTextEditor.document.getText();
	}

	const currentPosition = vscode.window.activeTextEditor.selection.active;

// Subtract one line from the current position to get the previous line number
const previousLineNumber = currentPosition.line - 1;
console.log("previous line"+ vscode.window.activeTextEditor.document.lineAt(currentPosition.line).text);
// Check if the previous line number is valid
if (previousLineNumber >= 0) {
  // Get the TextDocument object of the active editor
  const document = vscode.window.activeTextEditor.document;

  // Get the previous line's text using the line number
  const previousLineText = document.lineAt(previousLineNumber).text;

  // Do something with the previous line's text
  console.log('Previous line:', previousLineText);
} else {
  console.log('No previous line available.');
}

	vscode.window.showInformationMessage(text);
    const API_KEY = 'Bearer ' + process.env.API_KEY;
	console.log(API_KEY);
	try {
	  const response = await axios.post('https://api.openai.com/v1/chat/completions', {		
		  "model": "gpt-3.5-turbo",
		  "messages": 
		  [
			
			{
				"role": "system",
				"content": 'You are a AI robot. Always print the response with new line. Always give only first line'
			},
			  {
				  "role": "user",
				  "content": text
			  }
		  ]
	  
	  }, {
		headers: {
		  'Authorization': API_KEY,
		  'Content-Type': 'application/json',
		},
	  });
	  //const document = vscode.workspace.createTextDocument('response.java');
  //const edit = new vscode.WorkspaceEdit();
      vscode.window.showInformationMessage('response text is:' + JSON.stringify(response.data.choices[0].message.content));
	  const generatedText = JSON.stringify(response.data.choices[0].message.content);
	  const trimmedStr = generatedText.trim();

// Replace triple backticks with fenced code blocks
const finalMessage = trimmedStr.replace(/\\n/g, '\n');

	  vscode.window.showInformationMessage(finalMessage);
	  vscode.window.activeTextEditor.edit((editBuilder) => {
		editBuilder.insert(new vscode.Position(vscode.window.activeTextEditor.document.lineCount, 0), finalMessage);
	  });
	} catch (error) {
	  console.error('Error:', error);
	  vscode.window.showErrorMessage('Failed to call OpenAI API');
	}
  }

const makeApiCall = async () => {
	let apiUrl = "https://jsonplaceholder.typicode.com/posts/";
	const input = vscode.window.activeTextEditor;
		if(input){
			const document = input.document;			
			const selection = input.selection;
			const selectedText = document.getText(selection);
			vscode.window.showInformationMessage(selectedText);
			apiUrl = apiUrl+selectedText;
			//vscode.window.showInformationMessage(apiUrl);		
			//disposable = vscode.commands.executeCommand('openai-call.BOS-Copilot');

		}
		
	try {
	  //const response = await axios.get(apiUrl);
	  https.get(apiUrl, (response) => {
		let data = '';		
		response.on('data', (chunk) => {
			data += chunk;
	  let editor = vscode.window.activeTextEditor;			
			vscode.window.showInformationMessage('Is Editor active!' + editor);			
			if(editor){
				vscode.window.showInformationMessage(data);
			editor.edit(editBuilder => {editBuilder.insert(editor.selection.active, data);});
			}
		});
	});
	  
	} catch (error) {
	  console.error(error);
	}
  };
  

    // Define a command that calls makeApiCall repeatedly
const startApiPolling = async () => {
	//makeApiCall();
	callOpenAIAPI();
	// Call makeApiCall every 5 seconds
	//setInterval(makeApiCall, 5000);[
}
  // Register the startApiPolling command with a keybinding
const disposable = vscode.commands.registerCommand('bos-copilot.openAi', startApiPolling);

let webView = vscode.commands.registerCommand('extension.openSidebar', () => {
    // Create a WebviewPanel for the sidebar
    const panel = vscode.window.createWebviewPanel(
      'myExtensionSidebar',
      'My Extension Sidebar',
      vscode.ViewColumn.Beside,
      {
        enableScripts: true
      }
    );

    // Load the HTML content for the sidebar
    panel.webview.html = getWebviewContent(panel.webview);
  });

// Export the extension
module.exports = {
	activate: function(context) {
	  // Add the disposable to the context for cleanup
	  const sidebarProvider = new SidebarProvider(context.extensionUri);
context.subscriptions.push(
    vscode.window.registerWebviewViewProvider(
        "myextension-sidebar",
        sidebarProvider
    )
);

// Register a custom command
context.subscriptions.push(vscode.commands.registerCommand('myextension.askquestion', async () => {
    let response = await vscode.window.showInformationMessage("How are you doing?", "Good", "Bad");
    if (response === "Bad") {
        vscode.window.showInformationMessage("I'm sorry");
    }
}));

context.subscriptions.push(vscode.commands.registerCommand('myextension.sayhello', () => {
    vscode.window.showInformationMessage("Hello World!");
}));
	  context.subscriptions.push(disposable);
	  context.subscriptions.push(sidebarProvider);
	  context.subscriptions.push(webView);
	  deactivate();
	}
  };

  function getWebviewContent(webview) {
	// Get the active text editor's content
	const editor = vscode.window.activeTextEditor;
	const content = editor ? editor.document.getText() : 'No active editor content.';
  
	// Define the HTML content for the sidebar
	const htmlContent = `
	  <html>
		<body>
		  <h1>My Extension Sidebar</h1>
		  <p>Editor content: ${content}</p>
		  <button id="callAPIButton">Call API</button>
		  <button id="copyContentButton">Copy Editor Content</button>
		  <script>
			const vscode = acquireVsCodeApi();
  
			// Call the REST API
			document.getElementById('callAPIButton').addEventListener('click', () => {
			  // Make an API request using axios or any other library
			  axios.get('https://api.example.com')
				.then(response => {
				  // Handle the API response here
				  const message = {
					command: 'showMessage',
					text: response.data.message
				  };
				  vscode.postMessage(message);
				})
				.catch(error => {
				  // Handle the API error here
				  const message = {
					command: 'showMessage',
					text: 'API call failed!'
				  };
				  vscode.postMessage(message);
				});
			});
  
			// Copy editor content to the sidebar
			document.getElementById('copyContentButton').addEventListener('click', () => {
				console.log("testing");
			  const message = {
				command: 'copyEditorContent',
				text: ${JSON.stringify(content)}
			  };
			  vscode.postMessage(message);
			});
  
			// Receive messages from the extension
			window.addEventListener('message', event => {
			  const message = event.data;
  
			  if (message.command === 'showMessage') {
				// Show a message box when a specific message is received
				vscode.window.showInformationMessage(message.text);
			  }
			});
		  </script>
		</body>
	  </html>
	`;
  
	// Handle webview messages from the sidebar
	webview.onDidReceiveMessage(message => {
	  if (message.command === 'copyEditorContent') {
		// Copy editor content to the clipboard
		vscode.env.clipboard.writeText(message.text);
	  }
	});
  
	return htmlContent;
  }
  

/**
 * @param {vscode.ExtensionContext} context
 */
/*
function activate(context) {

	// Use the console to output diagnostic information (console.log) and errors (console.error)
	// This line of code will only be executed once when your extension is activated
	console.log('Congratulations, your extension "bos-copilot" is now active!');

	// The command has been defined in the package.json file
	// Now provide the implementation of the command with  registerCommand
	// The commandId parameter must match the command field in package.json
	let disposable = vscode.commands.registerCommand('bos-copilot.helloWorld', function () {
		// The code you place here will be executed every time your command is executed

		// Display a message box to the user
		vscode.window.showInformationMessage('Hello World from bos-copilot!');
	});

	context.subscriptions.push(disposable);
}
*/
// This method is called when your extension is deactivated
function deactivate() {}
/*
module.exports = {
	activate,
	deactivate
}*/
