// The module 'vscode' contains the VS Code extensibility API
// Import the module and reference it with the alias vscode in your code below
const vscode = require('vscode');
const https = require('https');
const axios = require('axios');
//require('dotenv').config();
console.log(process.env);

// This method is called when your extension is activated
// Your extension is activated the very first time the command is executed

async function callOpenAIAPI() {
	const seletedText = vscode.window.activeTextEditor.selection;
	let text = vscode.window.activeTextEditor.document.getText(seletedText);
	if(text !=null)
	{
		text = vscode.window.activeTextEditor.document.getText();
	}
	vscode.window.showInformationMessage(text);
    const API_KEY = 'Bearer ' + process.env.API_KEY;
	console.log(API_KEY);
	try {
	  const response = await axios.post('https://api.openai.com/v1/chat/completions', {		
		  "model": "gpt-3.5-turbo",
		  "messages": 
		  [
			  {
				  "role": "user",
				  "content": text
			  }
		  ]
	  
	  }, {
		headers: {
		  'Authorization': API_KEY,
		  'Content-Type': 'application/json',
		},
	  });
	  //const document = vscode.workspace.createTextDocument('response.java');
  //const edit = new vscode.WorkspaceEdit();
      vscode.window.showInformationMessage('response text is:' + JSON.stringify(response.data.choices[0].message.content));
	  const generatedText = JSON.stringify(response.data.choices[0].message.content);
	  const trimmedStr = generatedText.trim();

// Replace triple backticks with fenced code blocks
const finalMessage = trimmedStr.replace(/\\n/g, '\n');

	  vscode.window.showInformationMessage(finalMessage);
	  vscode.window.activeTextEditor.edit((editBuilder) => {
		editBuilder.insert(new vscode.Position(vscode.window.activeTextEditor.document.lineCount, 0), finalMessage);
	  });
	} catch (error) {
	  console.error('Error:', error);
	  vscode.window.showErrorMessage('Failed to call OpenAI API');
	}
  }

const makeApiCall = async () => {
	let apiUrl = "https://jsonplaceholder.typicode.com/posts/";
	const input = vscode.window.activeTextEditor;
		if(input){
			const document = input.document;			
			const selection = input.selection;
			const selectedText = document.getText(selection);
			vscode.window.showInformationMessage(selectedText);
			apiUrl = apiUrl+selectedText;
			//vscode.window.showInformationMessage(apiUrl);		
			//disposable = vscode.commands.executeCommand('openai-call.BOS-Copilot');

		}
		
	try {
	  //const response = await axios.get(apiUrl);
	  https.get(apiUrl, (response) => {
		let data = '';		
		response.on('data', (chunk) => {
			data += chunk;
	  let editor = vscode.window.activeTextEditor;			
			vscode.window.showInformationMessage('Is Editor active!' + editor);			
			if(editor){
				vscode.window.showInformationMessage(data);
			editor.edit(editBuilder => {editBuilder.insert(editor.selection.active, data);});
			}
		});
	});
	  
	} catch (error) {
	  console.error(error);
	}
  };

  

    // Define a command that calls makeApiCall repeatedly
const startApiPolling = async () => {
	//makeApiCall();
	callOpenAIAPI();
	// Call makeApiCall every 5 seconds
	//setInterval(makeApiCall, 5000);[
}
  // Register the startApiPolling command with a keybinding
const disposable = vscode.commands.registerCommand('bos-copilot.openAi', startApiPolling);

// Export the extension
module.exports = {
	activate: function(context) {
	  // Add the disposable to the context for cleanup
	  context.subscriptions.push(disposable);
	  deactivate();
	}
  };

/**
 * @param {vscode.ExtensionContext} context
 */
/*
function activate(context) {

	// Use the console to output diagnostic information (console.log) and errors (console.error)
	// This line of code will only be executed once when your extension is activated
	console.log('Congratulations, your extension "bos-copilot" is now active!');

	// The command has been defined in the package.json file
	// Now provide the implementation of the command with  registerCommand
	// The commandId parameter must match the command field in package.json
	let disposable = vscode.commands.registerCommand('bos-copilot.helloWorld', function () {
		// The code you place here will be executed every time your command is executed

		// Display a message box to the user
		vscode.window.showInformationMessage('Hello World from bos-copilot!');
	});

	context.subscriptions.push(disposable);
}
*/
// This method is called when your extension is deactivated
function deactivate() {}
/*
module.exports = {
	activate,
	deactivate
}*/
